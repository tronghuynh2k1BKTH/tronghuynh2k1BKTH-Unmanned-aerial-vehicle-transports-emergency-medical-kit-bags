#include "MS5611.h"
#include "stm32f1xx_hal.h"

extern I2C_HandleTypeDef hi2c1;

calibrationParameters CalibrationParameters;
digitalValues DigitalValues;
calculationParameters CalculationParameters;

static void MS5611_Reset(void)
{
	uint8_t I2C_COMMAND[1] = {0};
	I2C_COMMAND[0] = MS5611_RESET;

	HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), I2C_COMMAND, sizeof(I2C_COMMAND), HAL_MAX_DELAY);
}

static void MS5611_ReadCalibrationData(void) //READ_PROM
{
	uint8_t rx_Buffer[2] = {0};

	uint8_t I2C_COMMAND[6] = {0};
	I2C_COMMAND[0] = PROM_READ_C1;
	I2C_COMMAND[1] = PROM_READ_C2;
	I2C_COMMAND[2] = PROM_READ_C3;
	I2C_COMMAND[3] = PROM_READ_C4;
	I2C_COMMAND[4] = PROM_READ_C5;
	I2C_COMMAND[5] = PROM_READ_C6;

	HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[0], sizeof(I2C_COMMAND[0]), HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
	CalibrationParameters.C1 = ((rx_Buffer[0] << 8) | (rx_Buffer[1]));

	HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[1], sizeof(I2C_COMMAND[1]), HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
	CalibrationParameters.C2 = ((rx_Buffer[0] << 8) | (rx_Buffer[1]));

	HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[2], sizeof(I2C_COMMAND[2]), HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
	CalibrationParameters.C3 = ((rx_Buffer[0] << 8) | (rx_Buffer[1]));

	HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[3], sizeof(I2C_COMMAND[3]), HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
	CalibrationParameters.C4 = ((rx_Buffer[0] << 8) | (rx_Buffer[1]));

	HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[4], sizeof(I2C_COMMAND[4]), HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
	CalibrationParameters.C5 = ((rx_Buffer[0] << 8) | (rx_Buffer[1]));

	HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[5], sizeof(I2C_COMMAND[5]), HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
	CalibrationParameters.C6 = ((rx_Buffer[0] << 8) | (rx_Buffer[1]));
}

static void MS5611_ReadDigitalValues(int osr)	//READ Raw data
{
	uint8_t rx_Buffer[3] = {0};

	uint8_t I2C_COMMAND[11] = {0};
	I2C_COMMAND[0] = D1_OSR_256;
	I2C_COMMAND[1] = D1_OSR_512;
	I2C_COMMAND[2] = D1_OSR_1024;
	I2C_COMMAND[3] = D1_OSR_2048;
	I2C_COMMAND[4] = D1_OSR_4096;
	I2C_COMMAND[5] = D2_OSR_256;
	I2C_COMMAND[6] = D2_OSR_512;
	I2C_COMMAND[7] = D2_OSR_1024;
	I2C_COMMAND[8] = D2_OSR_2048;
	I2C_COMMAND[9] = D2_OSR_4096;
	I2C_COMMAND[10] = ADC_READ;

	switch(osr)
	{
	case 256:
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[0], sizeof(I2C_COMMAND[0]), HAL_MAX_DELAY);
		HAL_Delay(50);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D1 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));

		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[5], sizeof(I2C_COMMAND[5]), HAL_MAX_DELAY);
		HAL_Delay(50);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D2 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));
		break;

	case 512:
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[1], sizeof(I2C_COMMAND[1]), HAL_MAX_DELAY);
		HAL_Delay(50);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D1 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));

		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[6], sizeof(I2C_COMMAND[6]), HAL_MAX_DELAY);
		HAL_Delay(50);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D2 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));
		break;

	case 1024:
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[2], sizeof(I2C_COMMAND[2]), HAL_MAX_DELAY);
		HAL_Delay(50);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D1 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));

		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[7], sizeof(I2C_COMMAND[7]), HAL_MAX_DELAY);
		HAL_Delay(50);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D2 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));
		break;

	case 2048:
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[3], sizeof(I2C_COMMAND[3]), HAL_MAX_DELAY);
		HAL_Delay(10);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D1 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));

		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[8], sizeof(I2C_COMMAND[8]), HAL_MAX_DELAY);
		HAL_Delay(10);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D2 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));

		break;

	case 4096:
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[4], sizeof(I2C_COMMAND[4]), HAL_MAX_DELAY);
		HAL_Delay(10);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D1 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));

		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[9], sizeof(I2C_COMMAND[9]), HAL_MAX_DELAY);
		HAL_Delay(10);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D2 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));

		break;

	default:
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[2], sizeof(I2C_COMMAND[2]), HAL_MAX_DELAY);
		HAL_Delay(50);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D1 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));

		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[7], sizeof(I2C_COMMAND[7]), HAL_MAX_DELAY);
		HAL_Delay(50);
		HAL_I2C_Master_Transmit(&hi2c1, (MS5611_DEVICE_ADDR<<1), &I2C_COMMAND[10], sizeof(I2C_COMMAND[10]), HAL_MAX_DELAY);
		HAL_I2C_Master_Receive(&hi2c1, (MS5611_DEVICE_ADDR<<1), rx_Buffer, sizeof(rx_Buffer), HAL_MAX_DELAY);
		DigitalValues.D2 = ((rx_Buffer[0] << 16) | (rx_Buffer[1] << 8) | (rx_Buffer[2]));
		break;
	}
}

static void MS5611_Read_Pressure(void)
{
	/* For dT, OFF, and SENS max and min values should be defined */

	/* dT */
	CalculationParameters.dT = DigitalValues.D2 - (CalibrationParameters.C5 << 8);

	if(CalculationParameters.dT < -16776960)
		CalculationParameters.dT = -16776960;

	if(CalculationParameters.dT > 16777216)
		CalculationParameters.dT = 16777216;

	/*TEMP*/
	CalculationParameters.TEMP = 2000 + (((long long)CalculationParameters.dT * (long long)CalibrationParameters.C6) >> 23);


	/* OFF */
	CalculationParameters.OFF = ((long long)CalibrationParameters.C2 << 16) + (((long long)CalibrationParameters.C4 * (long long)CalculationParameters.dT) >> 7);

	if(CalculationParameters.OFF < -8589672450)
		CalculationParameters.OFF = -8589672450;

	if(CalculationParameters.OFF > 12884705280)
		CalculationParameters.OFF = 12884705280;

	/* SENS */
	CalculationParameters.SENS = ((long long)CalibrationParameters.C1  << 15) + (((long long)CalibrationParameters.C3 * (long long)CalculationParameters.dT) >> 8);

	if(CalculationParameters.SENS < -4294836225)
		CalculationParameters.SENS = -4294836225;

	if(CalculationParameters.SENS > 6442352640)
		CalculationParameters.SENS = 6442352640;

	long long OFF2 = 0;
	long long SENS2 = 0;

	if (CalculationParameters.TEMP < 2000)
		{
		    OFF2 = 5 * (((long long)CalculationParameters.TEMP - 2000) * ((long long)CalculationParameters.TEMP - 2000)) >> 1;
		    SENS2 = 5 * (((long long)CalculationParameters.TEMP - 2000) * ((long long)CalculationParameters.TEMP - 2000)) >> 2;

		if (CalculationParameters.TEMP < -1500)
		{
		    OFF2 = OFF2 + 7 * (((long long)CalculationParameters.TEMP + 1500) * ((long long)CalculationParameters.TEMP + 1500));
		    SENS2 = SENS2 + ((11 * (((long long)CalculationParameters.TEMP + 1500) * ((long long)CalculationParameters.TEMP + 1500))) >> 1);
		}
	}

	CalculationParameters.OFF = CalculationParameters.OFF - OFF2;
	CalculationParameters.SENS = CalculationParameters.SENS - SENS2;

	CalculationParameters.P = (unsigned long) (((((DigitalValues.D1 * CalculationParameters.SENS) >> 21) - CalculationParameters.OFF)) >> 15);
}

static void MS5611_Read_Temperature(void)
{
	/* For dT, OFF, and SENS max and min values should be defined */

	/* dT */
	CalculationParameters.dT = DigitalValues.D2 - ((uint32_t)CalibrationParameters.C5 * pow(2,8));

	if(CalculationParameters.dT < -16776960)
		CalculationParameters.dT = -16776960;

	if(CalculationParameters.dT > 16777216)
		CalculationParameters.dT = 16777216;

	/* TEMP */
	CalculationParameters.TEMP =(double)(CalculationParameters.dT/100) * (double)(CalibrationParameters.C6/100);
	CalculationParameters.TEMP *= 10000;
	CalculationParameters.TEMP /= 8388608;
	CalculationParameters.TEMP +=2000;

	double TEMP2 = 0;

	if(CalculationParameters.TEMP < 2000){
		TEMP2 = (CalculationParameters.dT * CalculationParameters.dT) / pow(2,31);
	}

	CalculationParameters.TEMP = CalculationParameters.TEMP - TEMP2;
}

float MS5611_GetPressure(int osr)
{
	float actualPressure = 0;

	MS5611_ReadDigitalValues(osr);
	MS5611_Read_Pressure();

	actualPressure = CalculationParameters.P / 100.00;
	return actualPressure;
}

float MS5611_GetTemperature(int osr)
{
	float actualTemperature = 0;

	MS5611_ReadDigitalValues(osr);
	MS5611_Read_Temperature();

	actualTemperature = CalculationParameters.TEMP / 100.00;

	return actualTemperature;
}

double MS5611_GetAltitude_Below_Sealevel(double pressure, double seaLevelPressure)
{
	double temp = (double)pressure / (double)seaLevelPressure;
    return (44330.0f * (1.0f - pow(temp, 0.1902949f)));
}

void MS5611_Init(void)
{
	MS5611_Reset();
	HAL_Delay(100);
	MS5611_ReadCalibrationData();
}
