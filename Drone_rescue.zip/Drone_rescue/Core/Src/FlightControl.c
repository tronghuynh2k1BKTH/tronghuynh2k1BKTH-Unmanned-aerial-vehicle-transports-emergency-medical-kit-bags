//Header files
#include <FlightControl.h>

#define twoKpDef  1.0f//(2.0f * 0.5f) // 2 * proportional gain
#define twoKiDef  0.01f//(2.0f * 0.0f) // 2 * integral gain

static I2C_HandleTypeDef i2cHandler;

static float accelScalingFactor;
static float gyroScalingFactor;

static int16_t GyroRW[3];
static int16_t MagRW[3];

float twoKp = twoKpDef;                      // 2 * proportional gain (Kp)
float twoKi = twoKiDef;                      // 2 * integral gain (Ki)
float integralFBx = 0.0f;
float integralFBy = 0.0f;
float integralFBz = 0.0f;

void Calibration(my_offset_value *offset){
	my_raw_value myAccelRaw, myGyroRaw, myMagRaw;
		for(int i = 0 ; i < 500 ; i++)
		{
			MPU6050_Get_Accel_RawData_to_CaliBration(&myAccelRaw);
			MPU6050_Get_Gyro_RawData_to_CaliBration(&myGyroRaw);
			MPU6050_Get_Mag_RawData(&myMagRaw);
			HAL_Delay(10);
			//printf("%i\n\r",*status);
		    // Sum data
			offset->AX += myAccelRaw.x;
			offset->AY += myAccelRaw.y;
			offset->AZ += myAccelRaw.z;
			offset->GX += myGyroRaw.x;
			offset->GY += myGyroRaw.y;
			offset->GZ += myGyroRaw.z;
			offset->MX += myMagRaw.x;
			offset->MY += myMagRaw.y;
			offset->MZ += myMagRaw.z;
		}
		  // Average Data
		offset->AX /= 500;
		offset->AY /= 500;
		offset->AZ /= 500;
		offset->GX /= 500;
		offset->GY /= 500;
		offset->GZ /= 500;
		offset->MX /= 500;
		offset->MY /= 500;
		offset->MZ /= 500;
}

void MPU6050_Init(I2C_HandleTypeDef *I2Chnd)
{
	memcpy(&i2cHandler, I2Chnd, sizeof(*I2Chnd));
}

void I2C_Read(uint8_t ADDR, uint8_t *i2cBif, uint8_t NofData)
{
	uint8_t i2cBuf[2];
	uint8_t MPUADDR;

	//Shift address to make it proper to i2c operation
	MPUADDR = (MPU_ADDR<<1);
	i2cBuf[0] = ADDR;

	HAL_I2C_Master_Transmit(&i2cHandler, MPUADDR, i2cBuf, 1, 10);
	HAL_I2C_Master_Receive(&i2cHandler, MPUADDR, i2cBif, NofData, 100);
}

void I2C_Write8(uint8_t ADDR, uint8_t data)
{
	uint8_t i2cData[2];
	i2cData[0] = ADDR;
	i2cData[1] = data;
	uint8_t MPUADDR = (MPU_ADDR<<1);
	HAL_I2C_Master_Transmit(&i2cHandler, MPUADDR, i2cData, 2,100);
}

//4- MPU6050 Initialaztion Configuration
void MPU6050_Config(MPU_ConfigTypeDef *config)
{
	uint8_t Buffer = 0;
	//Clock Source
	//Reset Device
	I2C_Write8(PWR_MAGT_1_REG, 0x80);
	HAL_Delay(100);
	Buffer = config ->ClockSource & 0x07; //change the 7th bits of register
	Buffer |= (config ->Sleep_Mode_Bit << 6) &0x40; // change only the 7th bit in the register
	I2C_Write8(PWR_MAGT_1_REG, Buffer);
	HAL_Delay(100); // should wait 10ms after changeing the clock setting.

	//Set the Digital Low Pass Filter
	Buffer = 0;
	Buffer = config->CONFIG_DLPF & 0x07;
	I2C_Write8(CONFIG_REG, Buffer);

	//Select the Gyroscope Full Scale Range
	Buffer = 0;
	Buffer = (config->Gyro_Full_Scale << 3) & 0x18;
	I2C_Write8(GYRO_CONFIG_REG, Buffer);

	//Select the Accelerometer Full Scale Range
	Buffer = 0;
	Buffer = (config->Accel_Full_Scale << 3) & 0x18;
	I2C_Write8(ACCEL_CONFIG_REG, Buffer);
	//Set SRD To Default
	MPU6050_Set_SMPRT_DIV(0x04);

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Buffer = 0x00;
//	I2C_Write8(0x6A, Buffer);	// Disable i2c master mode
//	HAL_Delay(10);
//
//	Buffer = 0x02;
//	I2C_Write8(0x37, Buffer);	// Enable i2c master bypass mode
//	HAL_Delay(10);
//
//	Buffer = 0x18;
//    HAL_I2C_Mem_Write(&i2cHandler, 0x1E << 1, 0x00, 1, &Buffer, 1, 100);    // Sample rate = 75Hz
//    HAL_Delay(10);
//
//    Buffer = 0x60;
//    HAL_I2C_Mem_Write(&i2cHandler, 0x1E << 1, 0x01, 1, &Buffer, 1, 100);    // Full scale = +/- 2.5 Gauss
//    HAL_Delay(10);
//
//    Buffer = 0x00;
//    HAL_I2C_Mem_Write(&i2cHandler, 0x1E << 1, 0x02, 1, &Buffer, 1, 100);        // Continuous measurement mode
//    HAL_Delay(10);
//
//    Buffer = 0x00;
//    HAL_I2C_Mem_Write(&i2cHandler, 0xD0, 0x37, 1, &Buffer, 1, 100);          // Disable i2c master bypass mode
//    HAL_Delay(10);
//
//    Buffer = 0x22;
//    HAL_I2C_Mem_Write(&i2cHandler, 0xD0, 0x6A, 1, &Buffer, 1, 100);        // Enable i2c master mode
//    HAL_Delay(10);
//
//    //Configure the MPU6050 to automatically read the magnetometer
//
//    Buffer = 0x1E | 0x80;
//    HAL_I2C_Mem_Write(&i2cHandler, 0xD0, 0x25, 1, &Buffer, 1, 100);        // Access Slave into read mode
//    HAL_Delay(10);
//
//    Buffer = 0x03;
//    HAL_I2C_Mem_Write(&i2cHandler, 0xD0, 0x26, 1, &Buffer, 1, 100);         // Slave REG for reading to take place
//    HAL_Delay(10);
//
//    Buffer = 0x80 | 0x06;
//    HAL_I2C_Mem_Write(&i2cHandler, 0xD0, 0x27, 1, &Buffer, 1, 100);        // Number of data bytes
//    HAL_Delay(10);
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//Accelerometer Scaling Factor, Set the Accelerometer and Gyroscope Scaling Factor
	switch (config->Accel_Full_Scale)
	{
		case AFS_SEL_2g:
			accelScalingFactor = (2000.0f/32768.0f);
			break;

		case AFS_SEL_4g:
			accelScalingFactor = (4000.0f/32768.0f);
				break;

		case AFS_SEL_8g:
			accelScalingFactor = (8000.0f/32768.0f);
			break;

		case AFS_SEL_16g:
			accelScalingFactor = (16000.0f/32768.0f);
			break;

		default:
			break;
	}
	//Gyroscope Scaling Factor
	switch (config->Gyro_Full_Scale)
	{
		case FS_SEL_250:
			gyroScalingFactor = 250.0f/32768.0f;
			break;

		case FS_SEL_500:
				gyroScalingFactor = 500.0f/32768.0f;
				break;

		case FS_SEL_1000:
			gyroScalingFactor = 1000.0f/32768.0f;
			break;

		case FS_SEL_2000:
			gyroScalingFactor = 2000.0f/32768.0f;
			break;

		default:
			break;
	}

}

//6- Set Sample Rate Divider
void MPU6050_Set_SMPRT_DIV(uint8_t SMPRTvalue)
{
	I2C_Write8(SMPLRT_DIV_REG, SMPRTvalue);
}

//9- Get Accel Raw Data
void MPU6050_Get_Accel_RawData(my_raw_value *rawDef)
{
	uint8_t i2cBuf[2];
	uint8_t AcceArr[6], GyroArr[6];

	I2C_Read(INT_STATUS_REG, &i2cBuf[1],1);
	if((i2cBuf[1]&&0x01))
	{
		I2C_Read(ACCEL_XOUT_H_REG, AcceArr,6);

		//Accel Raw Data
		rawDef->x = ((AcceArr[0]<<8) + AcceArr[1]); // x-Axis
		rawDef->y = ((AcceArr[2]<<8) + AcceArr[3]); // y-Axis
		rawDef->z = ((AcceArr[4]<<8) + AcceArr[5]); // z-Axis
		//Gyro Raw Data
		I2C_Read(GYRO_XOUT_H_REG, GyroArr,12);
		GyroRW[0] = ((GyroArr[0]<<8) + GyroArr[1]);
		GyroRW[1] = (GyroArr[2]<<8) + GyroArr[3];
		GyroRW[2] = ((GyroArr[4]<<8) + GyroArr[5]);
	}
}

//12- Get Gyro Raw Data
void MPU6050_Get_Gyro_RawData(my_raw_value *rawDef)
{

	//Accel Raw Data
	rawDef->x = GyroRW[0];
	rawDef->y = GyroRW[1];
	rawDef->z = GyroRW[2];

}

void MPU6050_Get_Mag_RawData(my_raw_value *rawDef)
{
	uint8_t MagArr[6];
	I2C_Read(0x49, MagArr,6);
	MagRW[0] =  ((MagArr[0]<<8) + MagArr[1]);
	MagRW[1] =	((MagArr[2]<<8) + MagArr[3]);
	MagRW[2] =	((MagArr[4]<<8) + MagArr[5]);
	//Accel Raw Data
	rawDef->x = MagRW[0];
	rawDef->y = MagRW[1];
	rawDef->z = MagRW[2];

}

void Update_Scaled_Value(my_raw_value myAccelRaw, my_raw_value myGyroRaw, my_raw_value myMagRaw, my_offset_value offset, my_IMU_scaled_value *scaled_Value){
	  scaled_Value->axg = (float)(myAccelRaw.x - offset.AX) / 4096.0; // offset.AX //35
	  scaled_Value->ayg = (float)(myAccelRaw.y - offset.AY) / 4096.0; // offset.AY
	  scaled_Value->azg = (float)(myAccelRaw.z - offset.AZ) / 4096.0; // offset.AZ
	  scaled_Value->gxrs = (float)((float)(myGyroRaw.x - offset.GX) / 16.384 * 0.01745329); //degree to radians - offset.GX
	  scaled_Value->gyrs = (float)((float)(myGyroRaw.y - offset.GY) / 16.384 * 0.01745329); //degree to radians - offset.GY
	  scaled_Value->gzrs = (float)((float)(myGyroRaw.z - offset.GZ) / 16.384 * 0.01745329); //degree to radians - offset.GZ
	  scaled_Value->mx = (float)(myMagRaw.x - offset.MX) / 660.0; // offset.AX
	  scaled_Value->my = (float)(myMagRaw.y - offset.MY) / 660.0; // offset.AY
	  scaled_Value->mz = (float)(myMagRaw.z - offset.MZ) / 660.0; // offset.AZ
	  // Degree to Radians Pi / 180 = 0.01745329251994329576923690768489
}

void MahonyAHRSupdateIMU(my_IMU_scaled_value scaled_Value, float sampleFreq, my_quaternion *qVol){
	  float norm;
	  float halfvx, halfvy, halfvz;
	  float halfex, halfey, halfez;
	  float qa, qb, qc;

	  // Compute feedback only if accelerometer measurement valid (avoids NaN in accelerometer normalisation)
	  if(!((scaled_Value.axg == 0.0f) && (scaled_Value.ayg == 0.0f) && (scaled_Value.azg == 0.0f))) {

	    // Normalise accelerometer measurement
	    norm = sqrt(scaled_Value.axg * scaled_Value.axg + scaled_Value.ayg * scaled_Value.ayg + scaled_Value.azg * scaled_Value.azg);
	    scaled_Value.axg /= norm;
	    scaled_Value.ayg /= norm;
	    scaled_Value.azg /= norm;

	    // Estimated direction of gravity and vector perpendicular to magnetic flux
	    halfvx = qVol->q1 * qVol->q3 - qVol->q0 * qVol->q2;
	    halfvy = qVol->q0 * qVol->q1 + qVol->q2 * qVol->q3;
	    halfvz = qVol->q0 * qVol->q0 - 0.5f + qVol->q3 * qVol->q3;

	    // Error is sum of cross product between estimated and measured direction of gravity
	    halfex = (scaled_Value.ayg * halfvz - scaled_Value.azg * halfvy);
	    halfey = (scaled_Value.azg * halfvx - scaled_Value.axg * halfvz);
	    halfez = (scaled_Value.axg * halfvy - scaled_Value.ayg * halfvx);

	    // Compute and apply integral feedback if enabled
	    if(twoKi > 0.0f) {
	      integralFBx += twoKi * halfex * (1.0f / sampleFreq);  // integral error scaled by Ki
	      integralFBy += twoKi * halfey * (1.0f / sampleFreq);
	      integralFBz += twoKi * halfez * (1.0f / sampleFreq);
	      scaled_Value.gxrs += integralFBx;  // apply integral feedback
	      scaled_Value.gyrs += integralFBy;
	      scaled_Value.gzrs += integralFBz;
	    }
	    else {
	      integralFBx = 0.0f; // prevent integral windup
	      integralFBy = 0.0f;
	      integralFBz = 0.0f;
	    }

	    // Apply proportional feedback
	    scaled_Value.gxrs += twoKp * halfex;
	    scaled_Value.gyrs += twoKp * halfey;
	    scaled_Value.gzrs += twoKp * halfez;
	  }

	  // Integrate rate of change of quaternion
	  scaled_Value.gxrs *= (0.5f * (1.0f / sampleFreq));   // pre-multiply common factors
	  scaled_Value.gyrs *= (0.5f * (1.0f / sampleFreq));
	  scaled_Value.gzrs *= (0.5f * (1.0f / sampleFreq));
	  qa = qVol->q0;
	  qb = qVol->q1;
	  qc = qVol->q2;
	  qVol->q0 += (-qb * scaled_Value.gxrs - qc * scaled_Value.gyrs - qVol->q3 * scaled_Value.gzrs);
	  qVol->q1 += (qa * scaled_Value.gxrs + qc * scaled_Value.gzrs - qVol->q3 * scaled_Value.gyrs);
	  qVol->q2 += (qa * scaled_Value.gyrs - qb * scaled_Value.gzrs + qVol->q3 * scaled_Value.gxrs);
	  qVol->q3 += (qa * scaled_Value.gzrs + qb * scaled_Value.gyrs - qc * scaled_Value.gxrs);

	  // Normalise quaternion
	  norm = sqrt(qVol->q0 * qVol->q0 + qVol->q1 * qVol->q1 + qVol->q2 * qVol->q2 + qVol->q3 * qVol->q3);
	  qVol->q0 /= norm;
	  qVol->q1 /= norm;
	  qVol->q2 /= norm;
	  qVol->q3 /= norm;
}

void mpu6050_getRollPitchYaw(my_quaternion qVol, my_RPY *rpy){	//57.29577951 = 180/pi
	  rpy->yaw   = -atan2(2.0f * (qVol.q1 * qVol.q2 + qVol.q0 * qVol.q3), qVol.q0 * qVol.q0 + qVol.q1 * qVol.q1 - qVol.q2 * qVol.q2 - qVol.q3 * qVol.q3) * 57.29577951;
	  rpy->pitch = asin(2.0f * (qVol.q1 * qVol.q3 - qVol.q0 * qVol.q2)) * 57.29577951;
	  rpy->roll  = atan2(2.0f * (qVol.q0 * qVol.q1 + qVol.q2 * qVol.q3), qVol.q0 * qVol.q0 - qVol.q1 * qVol.q1 - qVol.q2 * qVol.q2 + qVol.q3 * qVol.q3) * 57.29577951;
}

void MPU6050_Get_Accel_RawData_to_CaliBration(my_raw_value *rawDef)
{
	uint8_t i2cBuf[2];
	uint8_t AcceArr[6], GyroArr[6];

	I2C_Read(INT_STATUS_REG, &i2cBuf[1],1);
	if((i2cBuf[1]&&0x01))
	{
		I2C_Read(ACCEL_XOUT_H_REG, AcceArr,6);

		//Accel Raw Data
		rawDef->x = ((AcceArr[0]<<8) + AcceArr[1]); // x-Axis
		rawDef->y = ((AcceArr[2]<<8) + AcceArr[3]); // y-Axis
		rawDef->z = ((AcceArr[4]<<8) + AcceArr[5]) - 4096; // z-Axis
		//Gyro Raw Data
		I2C_Read(GYRO_XOUT_H_REG, GyroArr,6);
		GyroRW[0] = ((GyroArr[0]<<8) + GyroArr[1]);
		GyroRW[1] = (GyroArr[2]<<8) + GyroArr[3];
		GyroRW[2] = ((GyroArr[4]<<8) + GyroArr[5]);
	}
}

void MPU6050_Get_Gyro_RawData_to_CaliBration(my_raw_value *rawDef)
{
	//Accel Raw Data
	rawDef->x = GyroRW[0];
	rawDef->y = GyroRW[1];
	rawDef->z = GyroRW[2];
}

void PID(my_RPY *angle, PID_param *pid, int rop, int Init_CCR, float desired_roll_angle, float desired_pitch_angle, float desired_yaw_angle)
{
    //pid->elapsedTime = 0.001;
	pid->elapsedTime = 0.0005;

	pid->roll_error = angle->roll - desired_roll_angle;//0.0f; // desired_angle = 0
	pid->pitch_error = angle->pitch - desired_pitch_angle;//0.0f; // desired_angle = 0
	pid->yaw_error = angle->yaw - desired_yaw_angle;//0.0f; // desired_angle = 0

    pid->pid_p_roll = pid->Kp_roll*pid->roll_error;
    pid->pid_p_pitch = pid->Kp_pitch*pid->pitch_error; // tach Kp roll & pitch
    pid->pid_p_yaw = pid->Kp_yaw*pid->yaw_error; // tach Kp roll & pitch

    if (-3 < pid->roll_error && pid->roll_error < 3)
    {
      pid->pid_i_roll = pid->pid_i_roll+(pid->Ki_roll*pid->roll_error);
    }
    if (-3 < pid->pitch_error && pid->pitch_error < 3)
    {
      pid->pid_i_pitch = pid->pid_i_pitch+(pid->Ki_pitch*pid->pitch_error);
    }
    if (-3 < pid->yaw_error && pid->yaw_error < 3)
    {
      pid->pid_i_yaw = pid->pid_i_yaw+(pid->Ki_yaw*pid->yaw_error);
    }

    pid->pid_d_roll = pid->Kd_roll*((pid->roll_error - pid->previous_error_roll)/pid->elapsedTime);
    pid->pid_d_pitch = pid->Kd_pitch*((pid->pitch_error - pid->previous_error_pitch)/pid->elapsedTime);
    pid->pid_d_yaw = pid->Kd_yaw*((pid->yaw_error - pid->previous_error_yaw)/pid->elapsedTime);


    //final PID values
    pid->PID_total_roll = pid->pid_p_roll + pid->pid_i_roll + pid->pid_d_roll;
    pid->PID_total_pitch = pid->pid_p_pitch + pid->pid_i_pitch + pid->pid_d_pitch;
    pid->PID_total_yaw = pid->pid_p_yaw + pid->pid_i_yaw + pid->pid_d_yaw;

    if(pid->PID_total_roll < -1000)    {pid->PID_total_roll = 0;}
    if(pid->PID_total_roll > 1000)    {pid->PID_total_roll = 0;}
    if(pid->PID_total_pitch < -1000)    {pid->PID_total_pitch = 0;}
    if(pid->PID_total_pitch > 1000)    {pid->PID_total_pitch = 0;}
    if(pid->PID_total_yaw < -1000)    {pid->PID_total_yaw = 0;}
    if(pid->PID_total_yaw > 1000)    {pid->PID_total_yaw = 0;}

//  1 | 2
//  --o--
//	4 | 3
    pid->pwm_LF_1 = Init_CCR - pid->PID_total_roll - pid->PID_total_pitch + pid->PID_total_yaw; // throttle = 1300
    pid->pwm_RF_2 = Init_CCR + pid->PID_total_roll - pid->PID_total_pitch - pid->PID_total_yaw;
    pid->pwm_RB_3 = Init_CCR + pid->PID_total_roll + pid->PID_total_pitch + pid->PID_total_yaw; // throttle = 1300
    pid->pwm_LB_4 = Init_CCR - pid->PID_total_roll + pid->PID_total_pitch - pid->PID_total_yaw;

    //Right
    if(pid->pwm_RF_2 < 1000)    {        pid->pwm_RF_2 = 1000;    }
    if(pid->pwm_RF_2 > 2000)    {        pid->pwm_RF_2 = 2000;    }
    //Left
    if(pid->pwm_LB_4 < 1000)    {    	pid->pwm_LB_4 = 1000;    }
    if(pid->pwm_LB_4 > 2000)    {    	pid->pwm_LB_4 = 2000;    }
    //Right
    if(pid->pwm_RB_3 < 1000)    {        pid->pwm_RB_3 = 1000;    }
    if(pid->pwm_RB_3 > 2000)    {        pid->pwm_RB_3 = 2000;    }
    //Left
    if(pid->pwm_LF_1 < 1000)    {    	pid->pwm_LF_1 = 1000;    }
    if(pid->pwm_LF_1 > 2000)    {    	pid->pwm_LF_1 = 2000;    }

    pid->previous_error_roll = pid->roll_error;
    pid->previous_error_pitch = pid->pitch_error;
    pid->previous_error_yaw = pid->yaw_error;
}

void MahonyAHRSupdate(my_IMU_scaled_value scaled_Value, float sampleFreq, my_quaternion *qVol) {
	float Norm;
    float q0q0, q0q1, q0q2, q0q3, q1q1, q1q2, q1q3, q2q2, q2q3, q3q3;
	float hx, hy, bx, bz;
	float halfvx, halfvy, halfvz, halfwx, halfwy, halfwz;
	float halfex, halfey, halfez;
	float qa, qb, qc;

	// Use IMU algorithm if magnetometer measurement invalid (avoids NaN in magnetometer normalisation)
	if((scaled_Value.mx == 0.0f) && (scaled_Value.my == 0.0f) && (scaled_Value.mz == 0.0f)) {
		MahonyAHRSupdateIMU(scaled_Value, sampleFreq, qVol);
		return;
	}

	// Compute feedback only if accelerometer measurement valid (avoids NaN in accelerometer normalisation)
	if(!((scaled_Value.axg == 0.0f) && (scaled_Value.ayg == 0.0f) && (scaled_Value.azg == 0.0f))) {

		// Normalise accelerometer measurement
		Norm = sqrt(scaled_Value.axg * scaled_Value.axg + scaled_Value.ayg * scaled_Value.ayg + scaled_Value.azg * scaled_Value.azg);
	    scaled_Value.axg /= Norm;
	    scaled_Value.ayg /= Norm;
	    scaled_Value.azg /= Norm;

		// Normalise magnetometer measurement
		Norm = sqrt(scaled_Value.mx * scaled_Value.mx + scaled_Value.my * scaled_Value.my + scaled_Value.mz * scaled_Value.mz);
		scaled_Value.mx /= Norm;
		scaled_Value.my /= Norm;
		scaled_Value.mz /= Norm;

        // Auxiliary variables to avoid repeated arithmetic
        q0q0 = qVol->q0 * qVol->q0;
        q0q1 = qVol->q0 * qVol->q1;
        q0q2 = qVol->q0 * qVol->q2;
        q0q3 = qVol->q0 * qVol->q3;
        q1q1 = qVol->q1 * qVol->q1;
        q1q2 = qVol->q1 * qVol->q2;
        q1q3 = qVol->q1 * qVol->q3;
        q2q2 = qVol->q2 * qVol->q2;
        q2q3 = qVol->q2 * qVol->q3;
        q3q3 = qVol->q3 * qVol->q3;

        // Reference direction of Earth's magnetic field
        hx = 2.0f * (scaled_Value.mx * (0.5f - q2q2 - q3q3) + scaled_Value.my * (q1q2 - q0q3) + scaled_Value.mz * (q1q3 + q0q2));
        hy = 2.0f * (scaled_Value.mx * (q1q2 + q0q3) + scaled_Value.my * (0.5f - q1q1 - q3q3) + scaled_Value.mz * (q2q3 - q0q1));
        bx = sqrt(hx * hx + hy * hy);
        bz = 2.0f * (scaled_Value.mx * (q1q3 - q0q2) + scaled_Value.my * (q2q3 + q0q1) + scaled_Value.mz * (0.5f - q1q1 - q2q2));

		// Estimated direction of gravity and magnetic field
		halfvx = q1q3 - q0q2;
		halfvy = q0q1 + q2q3;
		halfvz = q0q0 - 0.5f + q3q3;
        halfwx = bx * (0.5f - q2q2 - q3q3) + bz * (q1q3 - q0q2);
        halfwy = bx * (q1q2 - q0q3) + bz * (q0q1 + q2q3);
        halfwz = bx * (q0q2 + q1q3) + bz * (0.5f - q1q1 - q2q2);

		// Error is sum of cross product between estimated direction and measured direction of field vectors
		halfex = (scaled_Value.ayg * halfvz - scaled_Value.azg * halfvy) + (scaled_Value.my * halfwz - scaled_Value.mz * halfwy);
		halfey = (scaled_Value.azg * halfvx - scaled_Value.axg * halfvz) + (scaled_Value.mz * halfwx - scaled_Value.mx * halfwz);
		halfez = (scaled_Value.axg * halfvy - scaled_Value.ayg * halfvx) + (scaled_Value.mx * halfwy - scaled_Value.my * halfwx);

		// Compute and apply integral feedback if enabled
		if(twoKi > 0.0f) {
			integralFBx += twoKi * halfex * (1.0f / sampleFreq);	// integral error scaled by Ki
			integralFBy += twoKi * halfey * (1.0f / sampleFreq);
			integralFBz += twoKi * halfez * (1.0f / sampleFreq);
			scaled_Value.gxrs += integralFBx;	// apply integral feedback
			scaled_Value.gyrs += integralFBy;
			scaled_Value.gzrs += integralFBz;
		}
		else {
			integralFBx = 0.0f;	// prevent integral windup
			integralFBy = 0.0f;
			integralFBz = 0.0f;
		}

		// Apply proportional feedback
	    scaled_Value.gxrs += twoKp * halfex;
	    scaled_Value.gyrs += twoKp * halfey;
	    scaled_Value.gzrs += twoKp * halfez;
	}

	// Integrate rate of change of quaternion
	scaled_Value.gxrs *= (0.5f * (1.0f / sampleFreq));		// pre-multiply common factors
	scaled_Value.gyrs *= (0.5f * (1.0f / sampleFreq));
	scaled_Value.gzrs *= (0.5f * (1.0f / sampleFreq));
	qa = qVol->q0;
	qb = qVol->q1;
	qc = qVol->q2;
	qVol->q0 += (-qb * scaled_Value.gxrs - qc * scaled_Value.gyrs - qVol->q3 * scaled_Value.gzrs);
	qVol->q1 += (qa * scaled_Value.gxrs + qc * scaled_Value.gzrs - qVol->q3 * scaled_Value.gyrs);
	qVol->q2 += (qa * scaled_Value.gyrs - qb * scaled_Value.gzrs + qVol->q3 * scaled_Value.gxrs);
	qVol->q3 += (qa * scaled_Value.gzrs + qb * scaled_Value.gyrs - qc * scaled_Value.gxrs);

	// Normalise quaternion
	  Norm = sqrt(qVol->q0 * qVol->q0 + qVol->q1 * qVol->q1 + qVol->q2 * qVol->q2 + qVol->q3 * qVol->q3);
	  qVol->q0 /= Norm;
	  qVol->q1 /= Norm;
	  qVol->q2 /= Norm;
	  qVol->q3 /= Norm;
}
