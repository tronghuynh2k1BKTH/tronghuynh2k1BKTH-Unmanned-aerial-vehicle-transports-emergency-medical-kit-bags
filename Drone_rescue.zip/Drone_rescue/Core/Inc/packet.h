/*
 * packet.h
 *
 *  Created on: Dec 17, 2022
 *      Author: huynh
 */

#ifndef INC_PACKET_H_
#define INC_PACKET_H_

int Ascii_to_Int(char number);
float convert(char* value);

#endif /* INC_PACKET_H_ */
